function A = parseQSpace (A)
% < Description >
%
% A = parseQSpace (A)
%
% Check the input A is QSpace, struct, or something else. If the input is
% QSpace, then the output is the same as A. If the input is struct, convert
% the input to the QSpace that is the output. If something else, throws
% error.
%
% < Input >
% A : [QSpace, struct, or something else] Data to be checked or converted
%       to QSpace object.
%
% < Output >
% A : [QSpace] QSpace object whose content is equivalent to the input A.
%
% Written by S.Lee (May 02,2019)

if ~isempty(A) && ~isa(A,'QSpace')
    if isstruct(A)
        try
            A = QSpace(A);
        catch e
            fprintf('ERR: Input struct is not compatible with QSpace:\n');
            disp(A);
            rethrow(e);
        end
    else
        disp(A);
        error('ERR: Input is neither QSpace nor compatible with QSpace.');
    end
end

end