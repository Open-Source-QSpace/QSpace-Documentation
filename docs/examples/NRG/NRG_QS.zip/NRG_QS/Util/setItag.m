function varargout = setItag (varargin)
% < Description >
% 
% [op1 [,op2,...]] = setItag ('name1' [,'name2',...], op1 [,op2,...])
%
% Set itags of input QSpace objects by given names. Each name input is
% substituted to every two itags. For example of rank-3 operator w/
% {'','*','*'} with name input 's','op' gives {'s','s*','op*'}.
%
% NOTE. Original itags are removed!
%
% < Input >
% name1, .. : [char] (Any char vector variables in varargin) Name to be
%       substituted to itags.
% op1, .. : [QSpace] (Any QSpace or QSpace-equivalent struct variables in
%       varargin) QSpace objects. If the input is not QSpace but its
%       struct form, this function converts the input to QSpace.
%
% < Ouput >
% op1, .. : [QSpace] QSpace objects w/ new itags.
%
% Written by S.Lee (2015)
% Updated by S.Lee (Dec.22,2017): check # of inputs and outputs.
% Updated by S.Lee (Aug.03,2018): Now it deals with empty operators.
% Updated by S.Lee (May 02,2019): Updated the sanity check whether the
%       inputs are valid QSpace.


oks = cellfun(@ischar, varargin);

strs = varargin(oks);
ops = varargin(~oks);

if numel(ops) == 0
    error('ERR: No input of operators.');
elseif numel(ops) < nargout
    error('ERR: # of operator input arguments is smaller than # of requested output.');
end

for ito = (1:numel(ops))
    ops{ito} = parseQSpace(ops{ito});
    
    for ito2 = (1:numel(ops{ito}))
        if ~isempty(ops{ito}) && isfield(struct(ops{ito}),'info')
            if numel(ops{ito}(ito2).info.itags) > 2*numel(strs)
                display(ops{ito}(ito2));
                error(['ERR: # of names (= ',sprintf('%i',numel(strs)),') is not ',...
                    'enough for the operator input #',sprintf('%i',ito),'.']);
            end

            itagtmp = cellfun(@(x) ['a',x], ops{ito}(ito2).info.itags, 'UniformOutput',0);
            isouts = cellfun(@(x) strcmp(x(end),'*'), itagtmp);

            for itt = (1:numel(itagtmp))
                itagtmp{itt} = strs{ceil(itt/2)};

                if isouts(itt)
                    itagtmp{itt} = [itagtmp{itt},'*'];
                end
            end

            ops{ito}(ito2).info.itags = itagtmp;
        end
    end
end

varargout = ops;
    