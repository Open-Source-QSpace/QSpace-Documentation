function Cleft = updateLeftQS(Cleft,B,X,A)
% < Description >
%
% Cleft = updateLeftQS(Cleft,B,X,A)
%
% Contract the operator Cleft that act on the Hilbert space of the left
% part of the MPS (i.e., left of a given site) with the tensors B, X, and
% A, acting on the given site.
%
% < Input >
% Cleft : [tensor] Rank-2 or 3 tensor from the left part of the system. If
%       given as empty [], then Cleft is considered as the identity tensor
%       of rank 2 (for rank(X) < 4) or rank 3 (for rank(X) == 4).
% B, A : [tensors] Ket tensors, whose legs are ordered as left - bottom
%       (local physical) - right. In the contraction, the Hermitian
%       conjugate (i.e., bra form) of B is used, while A is contracted as
%       it is. This convention of inputting B as a ket tensor reduces extra
%       computational cost of taking the Hermitian conjugate of B.
% X : [tensor] Local operator with rank 2 or 3. If given as empty [], then
%       X is considered as the identity.
%
% < Output >
% Cleft : [tensor] Contracted tensor. The tensor network diagrams
%       describing the contraction are as follows.
%       * When Cleft is rank-3 and X is rank-2:
%                    1     2
%          /--------->- A ->--            /---->-- 2
%          |            | 3               |
%        2 ^            ^                 |
%          |    3       | 2               |      
%        Cleft---       X         =>    Cleft ---- 3
%          |            | 1               |
%        1 ^            ^                 |
%          |            | 3               |
%          \---------<- B*-<--            \----<-- 1
%                    1     2
%       * When Cleft is rank-2 and X is rank-3:
%                    1     2
%          /--------->- A ->--            /---->-- 2
%          |            | 3               |
%        2 ^            ^                 |
%          |          2 |   3             |      
%        Cleft          X ----    =>    Cleft ---- 3
%          |          1 |                 |
%        1 ^            ^                 |
%          |            | 3               |
%          \---------<- B*-<--            \----<-- 1
%                    1     2
%       * When both Cleft and X are rank-3:
%                    1     2
%          /--------->- A ->--            /---->-- 2
%          |            | 3               |
%        2 ^            ^                 |
%          |   3     3  | 2               |      
%        Cleft--------- X         =>    Cleft
%          |            | 1               |
%        1 ^            ^                 |
%          |            | 3               |
%          \---------<- B*-<--            \----<-- 1
%                    1     2
%       * When Cleft is rank3 and X is rank-4:
%                    1     2
%          /--------->- A ->--            /---->-- 2
%          |            | 3               |
%        2 ^            ^                 |
%          |   3    3   | 2               |      
%        Cleft--------- X ---- 4   =>   Cleft ---- 3
%          |            | 1               |
%        1 ^            ^                 |
%          |            | 3               |
%          \---------<- B*-<--            \----<-- 1
%                    1     2
%       Here B* denotes the complex conjugate of B.
%
% Written by H.Tu (May 3,2017); edited by S.Lee (May 19,2017)
% Rewritten by S.Lee (May 5,2019)
% Updated by S.Lee (May 27,2019): Case of rank-3 Cleft and rank-4 X is
%       added.
% Updated by S.Lee (Jul.28,2020): Minor fix for the case when Cleft == []
%       and rank(X) == 4.
% Adapted for QSpace by A.Gleis (May 5,2021)

% determine ranks
if ~isempty(Cleft)
    rankC = rank(Cleft);
else
    rankC = 2; % if empty, Cleft is implied to be identity
end
if ~isempty(X)
    rankX = rank(X);
else
    rankX = 2; % if empty, X is implied to be identity
end
rankA = rank(A);
rankB = rank(B);

% error checking
if ~isempty(Cleft) && ~any(rankC == [2 3])
    error('ERR: Rank of Cleft or Cright should be 2 or 3.');
end
if ~isempty(X) && ~any(rankX == (2:4))
    error('ERR: Rank of X should be 2, 3, or 4.');
end
if rankA ~= 3
    error('ERR: Rank of A should be 3.');
end
if rankB ~= 3
    error('ERR: Rank of B should be 3.');
end

if ~isempty(X)
    T = contract(A,3,X,2); % contract A and X
else
    T = A; % X is identity
end
if ~isempty(Cleft) % contract with Cleft if not empty
    if (rankC > 2) && (rankX > 2)
        T = contract(Cleft,[2 3],T,[1 4]);
    else
        T = contract(Cleft,2,T,1);
        if rankC > 2 % permute third leg of Cleft to be last
            T = permute(T,[1,rankC:rank(T),2]);
        end
    end
end
Cleft = contract(conj(B),[1 3],T,[1 3]); % contract with conj(B)

end