function A = delEmptyQS (A)
% < Description >
%
% A = delEmptyQS (A)
%
% Remove data sectors of QSpace tensor A whose contents are [] (empty) and
% also remove the corresponding Q (quantum number) and cgr (Clebsch-Gordan
% coefficients).
%
% < Input & Output >
% A : [QSpace] Tensor.
%
% Written by S.Lee (May 17,2017)

oks = cellfun('isempty',A.data);

if any(oks)
    A.data(oks) = []; % clean up data
    
    for itq = (1:numel(A.Q))
        A.Q{itq}(oks,:) = []; % clean up Q
    end
    
    if ~isempty(A.info.cgr)
        A.info.cgr(oks,:) = []; % clean up cgr
    end
end

end