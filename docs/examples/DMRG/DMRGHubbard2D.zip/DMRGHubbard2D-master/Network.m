classdef Network < handle

	properties
		mps % matrix product state
		mpo % matrix product operator
		env % partial contraction of <mps|mpo|mps>
		model_iden % identity operator for model

		% numerical parameters
		D
		D_prime
		D_hat
		D_tilde
		num_davidson
		eps_davidson
		num_zero
		opt_enum

		timetracker
	end

	methods
		%                       ________
		%       ----------------|mps{i}|-----          ------------
		%       |               --------               |
		%       |                  |                   |
		% _____________         ________            ________
		% |env{i_prev}|---------|mpo{i}|-----  ->   |env{i}|-------
		% -------------         --------            --------
		%       |                  |                   |
		%       |           ______________             |
		%       ------------|conj(mps{i})|---          ------------
		%                   --------------
		function [obj] = env_contract( obj, i, i_prev ) % a.k.a "left update" and "right update"
			obj.timetracker.init("env contract");

			obj.env{i} = obj.mps{i};
			if i>1 & i<length(obj.mps)
				obj.env{i} = contract(obj.env{i},obj.env{i_prev});
			end

			obj.env{i} = contract(obj.env{i},obj.mpo{i});
			mps_out = conj(obj.mps{i});
			mps_out.info.itags = pitags.conj_phys(mps_out.info.itags,length(obj.mps));

			obj.env{i} = contract(obj.env{i},mps_out);
			obj.timetracker.fin("env contract");
		end

		function [mps1_out,mps2_out] = shrewd_cbe( obj, i1, i2 )

			left_env = QSpace;
			right_env = QSpace;
			if i1<i2
				if i1>1
					left_env = obj.env{i1-1};
				end
				if i2<length(obj.mps)
					right_env = obj.env{i2+1};
				end
			else
				left_env = QSpace;
				if i1<length(obj.mps)
					left_env = obj.env{i1+1};
				end
				if i2>1
					right_env = obj.env{i2-1};
				end
			end
			mps1 = obj.mps{i1};
			mpo1 = obj.mpo{i1};

			mps2 = obj.mps{i2};
			mpo2 = obj.mpo{i2};

			cbe = CBE;
			[mps1_out,mps2_out,cbe_tracker] = cbe.shrewd_cbe( left_env, right_env, mps1, mps2, ...
				mpo1, mpo2, obj.model_iden, length(obj.mps), obj.D, obj.D_prime, obj.D_hat, obj.D_tilde );
			obj.timetracker.add(cbe_tracker);
		end

		%             psi = mps{i} * mps{i+1}
		%
		%               ____________________
		%       --------|       psi        |----------
		%       |       --------------------         |
		%       |           |           |            |
		% __________    ________  __________    __________           _______
		% |env{i-1}|----|mpo{i}|--|mpo{i+1}|----|env{i+2}|   ->   ---|H_psi|---
		% ----------    --------  ----------    ----------           -------
		%       |           |           |            |                |   |
		function [ten_out] = H_psi2( obj, psi, i )
			obj.timetracker.init("Davidson H_psi2");
			ten_out = psi;
			if i>1
				ten_out = contract(ten_out,obj.env{i-1});
			end
			twosite_mpo = contract(obj.mpo{i},obj.mpo{i+1});
			ten_out = contract(ten_out,twosite_mpo);
			if i<length(obj.mps)-1
				ten_out = contract(ten_out,obj.env{i+2});
			end
			ten_out.info.itags = pitags.conj_phys(ten_out.info.itags,length(obj.mps));
			obj.timetracker.fin("Davidson H_psi2");
		end

		%             psi = mps{i}
		%
		%               _________
		%       --------|  psi  |--------
		%       |       ---------       |
		%       |           |           |
		% __________    ________  __________           _______
		% |env{i-1}|----|mpo{i}|--|env{i+1}|   ->   ---|H_psi|---
		% ----------    --------  ----------           -------
		%       |           |           |                 |
		function [ten_out] = H_psi1( obj, psi, i )
			obj.timetracker.init("Davidson H_psi1");
			ten_out = psi;
			if i>1
				ten_out = contract(ten_out,obj.env{i-1});
			end
			ten_out = contract(ten_out,obj.mpo{i});

			if i<length(obj.mps)
				ten_out = contract(ten_out,obj.env{i+1});
			end
			ten_out.info.itags = pitags.conj_phys(ten_out.info.itags,length(obj.mps));
			obj.timetracker.fin("Davidson H_psi1");
		end

		function [result] = get_first( obj, ten )
			if length(ten.data)==0
				result = 0;
			else
				result = ten.data{1}(1);
			end
		end

		% orthonormalize last element of "B" against all the others
		function [ten_out] = gram_schmidt( obj, B )
			obj.timetracker.init("Davidson Gram Schmidt");
			ten_out = B{end};
			for i=(1:length(B)-1)
				fac = obj.get_first(contract(ten_out,conj(B{i})));
				ten_out = qadd(ten_out,B{i},-fac);
			end
			sqrt_ = sqrt(obj.get_first(contract(ten_out,conj(ten_out))));
			ten_out = ten_out * (1/sqrt_);
			obj.timetracker.fin("Davidson Gram Schmidt");
		end

		% correction vector with Lanczos preconditioner
		function [ten_out] = corr_vec( obj, ten_in, E_0 )
			ten_out = ten_in * (1/(1-E_0));
		end

		% perpendicular norm
		function [norm] = perp_norm( obj, B, E_0 )
			obj.timetracker.init("Davidson perp norm");
			B_back = obj.corr_vec(B{end},E_0);
			for i=(1:length(B)-1)
				fac = obj.get_first(contract(B_back,conj(B{i})));
				B_back = qadd(B_back,B{i},-fac);
			end
			norm = sqrt(obj.get_first(contract(B_back,conj(B_back))));
			obj.timetracker.fin("Davidson perp norm");
		end

		% Davidson algorithm for ground state calculation
		% https://arxiv.org/pdf/cond-mat/0510321.pdf , Chapter 2.3
		function [ten_out] = davidson( obj, pos, fonesite )
			obj.timetracker.init("Davidson");

			sub_H = []; % Hamiltonian of Krylov-subspace
			B = {}; % tensors orthonormal to each other
			C = {}; % tensors of B multiplied by H_eff
			vec_0 = []; % ground state in Krylov subspace
			E_0 = 0; % ground state energy in Krylov subspace

			if fonesite
				psi = obj.mps{pos};
			else
				psi = contract(obj.mps{pos},obj.mps{pos+1});
			end
			B{end+1} = psi;
			psi = obj.gram_schmidt(B);
			B{end} = psi;

			if fonesite
				psi = obj.H_psi1( psi, pos );
			else
				psi = obj.H_psi2( psi, pos );
			end
			C{end+1} = permute(psi,pitags.get_perm(B{1}.info.itags,psi.info.itags));

			sub_H(1,1) = obj.get_first(contract(B{end},conj(C{end})));
			E_0 = sub_H(1,1);

			B{end+1} = C{end};

			[B{end}] = qadd(B{end},B{1},-E_0);

			vec_0(1) = 1;
			size = 1;

			fprintf("   energy: %.16f\n",E_0);

			for i=(2:obj.num_davidson+1)

				if obj.perp_norm(B,E_0)<obj.eps_davidson
					break;
				end

				B{end} = obj.corr_vec(B{end},E_0);
				B{end} = obj.gram_schmidt(B);

				if fonesite
					psi = obj.H_psi1(B{end},pos);
				else
					psi = obj.H_psi2(B{end},pos);
				end

				C{end+1} = permute(psi,pitags.get_perm(B{1}.info.itags,psi.info.itags));

				% expand Krylov subspace
				for j=(1:i)
					elem = obj.get_first(contract(B{end},conj(C{j})));
					sub_H(j,i) = elem;
					sub_H(i,j) = elem;
				end

				% diagonalize effective Hamitonian in Krylov subspace
				[V,D] = eig(sub_H);
				[d,ind] = sort(diag(D));
				E_0 = d(1);
				vec_0 = V(:,ind(1));

				fprintf("   energy: %.16f\n",E_0);

				% calculate residual vector
				obj.timetracker.init("Davidson residual vector");
				B{end+1} = QSpace;
				for j=(1:length(B)-1)
					temp = B{j} * (-E_0);
					temp = qadd(temp,C{j},1);
					B{end} = qadd(B{end},temp,vec_0(j));
				end
				obj.timetracker.fin("Davidson residual vector");

			end

			ten_out = QSpace;
			for j=(1:length(vec_0))
				ten_out = qadd(ten_out,B{j},vec_0(j));
			end

			obj.timetracker.fin("Davidson");
		end

		% sweep and optimize two sites at once
		function [obj] = twosite_sweep( obj, i )
			N = length(obj.mps);
			fonesite = false;

			for j=(1:N-1)
				if j>1
					obj.env_contract(j-1,j-2);
				end

				fprintf("sweep num: %s, sites: %s %s\n",string(i),string(j),string(j+1));
				psi = obj.davidson(j,fonesite);

				obj.timetracker.init("twosite SVD");

				if j<N-1
					psi_fac = Qfac;
					[obj.mps{j},obj.mps{j+1},info_] = psi_fac.qr_trunc(psi,pitags.get_right_itags(j+1),...
						pitags.get_left_itag(j+1),obj.D,obj.num_zero);
				else
					psi_fac = Qfac;
					[obj.mps{j},obj.mps{j+1},info_] = psi_fac.lq_trunc(psi,pitags.get_right_itags(j+1),...
						pitags.get_left_itag(j+1),obj.D,obj.num_zero);
				end
				obj.timetracker.fin("twosite SVD");
				fprintf("    %s\n",info_.info);

				fprintf("\n");
			end
			for j=(N-2:-1:2)
				obj.env_contract(j+2,j+3);

				fprintf("sweep num: %s, sites: %s %s\n",string(i),string(j),string(j+1));
				psi = obj.davidson(j,fonesite);
				psi_fac = Qfac;
				[obj.mps{j},obj.mps{j+1},info_] = psi_fac.lq_trunc(psi,pitags.get_right_itags(j+1),...
					pitags.get_left_itag(j+1),obj.D,obj.num_zero);
				fprintf("    %s\n",info_.info);

				fprintf("\n");
			end

			obj.env_contract(3,4);
		end

		function [dim] = get_dim( obj, ten_in, itag )
			[q_out,size_out] = obj.unique_sectors(ten_in,itag);
			dim = 0;
			for i=(1:length(size_out))
				dim = dim + size_out(i);
			end
		end

		% sweep and optimize one site with one bond expanded via CBE
		function [obj] = cbe_sweep( obj, i )
			N = length(obj.mps);
			fonesite = true;

			% sweep from left to right
			for j=(1:N-1)

				if j>1
					obj.env_contract(j-1,j-2);
				end

				if obj.opt_enum==2
					[obj.mps{j+1},obj.mps{j}] = obj.shrewd_cbe( j+1, j );
				end

				obj.env_contract(j+1,j+2);

				fprintf("sweep num: %s, sites: %s %s\n",string(i),string(j),string(j+1));
				psi = obj.davidson(j,fonesite);
				temp_itag = 'cbe_temp';
				temp_itag2 = 'cbe_temp*';
				svd_fac = Qfac;
				[obj.mps{j},wft,info_] = svd_fac.qr_trunc(psi,{pitags.get_left_itag2(j+1)},temp_itag,obj.D,obj.num_zero);
				fprintf("    %s\n",info_.info);
				obj.mps{j+1} = contract(obj.mps{j+1},wft);
				obj.mps{j}.info.itags = pitags.subst(obj.mps{j}.info.itags,temp_itag2,pitags.get_left_itag2(j+1));
				obj.mps{j+1}.info.itags = pitags.subst(obj.mps{j+1}.info.itags,temp_itag,pitags.get_left_itag(j+1));

				fprintf("\n");
			end

			% sweep from right to left
			for j=(N-1:-1:1)
				if j<N-1
					obj.env_contract(j+2,j+3);
				end

				if obj.opt_enum==2
					[obj.mps{j},obj.mps{j+1}] = obj.shrewd_cbe( j, j+1 );
				end

				obj.env_contract(j,j-1);

				fprintf("sweep num: %s, sites: %s %s\n",string(i),string(j),string(j+1));
				psi = obj.davidson(j+1,fonesite);
				temp_itag = 'cbe_temp';
				temp_itag2 = 'cbe_temp*';

				svd_fac = Qfac;
				[wft,obj.mps{j+1},info_] = svd_fac.lq_trunc(psi,pitags.get_right_itags(j+1),temp_itag,obj.D,obj.num_zero);
				fprintf("    %s\n",info_.info);

				obj.mps{j} = contract(obj.mps{j},wft);
				obj.mps{j}.info.itags = pitags.subst(obj.mps{j}.info.itags,temp_itag2,pitags.get_left_itag2(j+1));
				obj.mps{j+1}.info.itags = pitags.subst(obj.mps{j+1}.info.itags,temp_itag,pitags.get_left_itag(j+1));

				fprintf("\n");
			end

		end

		function [] = print_time( obj )
			obj.timetracker.print();
		end

	end
end
