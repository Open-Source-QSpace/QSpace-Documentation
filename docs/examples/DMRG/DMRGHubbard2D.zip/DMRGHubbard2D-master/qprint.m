function [result] = qprint( ten )
	if length(ten.info)>0
		rank = length(ten.info.itags);
		for i=(1:length(ten.data))
			reshape(ten.data{i},[1 numel(ten.data{i})])
		end
	else
		"empty"
	end
end
