classdef ham
	methods(Static)

		% add leg with vacuum state to operator
		function [op_out] = add_vac_leg( op_in, itag )
			vac = getvac(op_in);
			vac_tags = pitags.reset({itag});
			vac.info.itags = {vac_tags{1},pitags.toggle(vac_tags{1})};

			if pitags.is_out(itag)
				p_tag = pitags.get_phys_out(op_in.info.itags);
				p_out = pitags.get_index(op_in.info.itags,p_tag);

				iden = getIdentity(op_in,p_out,vac,1,pitags.set_out(p_tag));

				iden = conj(iden);
				op_out = contract(op_in,p_out,iden,3);
			else
				p_tag = pitags.get_phys_in(op_in.info.itags);
				p_in = pitags.get_index(op_in.info.itags,p_tag);

				iden = getIdentity(op_in,p_in,vac,1,pitags.set_out(p_tag));

				op_out = contract(op_in,p_in,iden,3);
			end
		end

		% remove leg with vacuum state at borders
		function [op_out] = remove_vac_leg_border( op_in, vtag )
			vindex = pitags.get_index(op_in.info.itags,vtag);

			if pitags.is_out(vtag)
				ptag = pitags.get_phys_out(op_in.info.itags);
				pindex = pitags.get_index(op_in.info.itags,ptag);
				iso = getIdentity(op_in,vindex,op_in,pindex,ptag);
				temp = zeros(2,1,1);
				temp(2) = 1; % final state
				for i=(1:length(iso.data))
					iso.data{i} = temp;
				end
			else
				ptag = pitags.get_phys_in(op_in.info.itags);
				pindex = pitags.get_index(op_in.info.itags,ptag);
				iso = getIdentity(op_in,vindex,op_in,pindex,pitags.toggle(ptag));
				iso = conj(iso);
				temp = zeros(2,1,1);
				temp(1) = 1; % initial state
				for i=(1:length(iso.data))
					iso.data{i} = temp;
				end
			end

			% QSpace has an inconsistent normalization: isometry * isometry^T
			% is only equal to identity for Abelian symmetries. For non-Abelian
			% symmetries, you pick up prefactors unequal to one. The following
			% four lines of code are a hack that deals with this.
			iden = contract(iso,[1 2],conj(iso),[1 2]);
			for i=(1:length(iden.data))
				iso.data{i} = iso.data{i} / sqrt(iden.data{i}(1));
			end

			op_out = contract(op_in,[vindex pindex],iso,[1 2]);
		end

		% for given degree-2 tensor (i.e. matrix), add a channel, i.e. two legs
		% that carry virtual quantum numbers of op_phys
		function [op_out] = add_channel( op_in, op_phys )
			op_out = ham.add_vac_leg(op_in,'temp*');
			v_index = pitags.get_index(op_phys.info.itags,'v*');
			vac_index = pitags.get_index(op_out.info.itags,'temp*');
			iso = getIdentity(op_out,vac_index,op_phys,v_index,'v*');
			op_out = contract(op_out,vac_index,iso,1);
		end

		% expand leg, i.e. add degeneracy of "deg" and assign state at "pos"
		function [op_out] = exp_leg( op_in, itag, deg, pos )
			index = pitags.get_index(op_in.info.itags,itag);
			iden = getIdentity(op_in,index);

			if strcmp(itag,iden.info.itags{1})
				iden = conj(iden);
				temp = sprintf('%s','temp');
			else
				temp = sprintf('%s','temp*');
			end
			iden.info.itags = {pitags.toggle(itag),temp};

			for i=(1:length(iden.data))
				iden.data{i} = zeros(1,deg);
				iden.data{i}(1,pos) = 1;
			end

			op_out = contract(op_in,iden);
			op_out.info.itags = pitags.subst(op_out.info.itags,temp,itag);
		end

		% add operator while minding position-dependent itags
		function [op_out] = opadd( op1, op2, fac, i )
			ps = string(i);
			i1 = sprintf('%s','cp'+ps);
			i2 = sprintf('%s','mpo'+string(i-1));
			i3 = sprintf('%s','p'+ps+'*');
			i4 = sprintf('%s','mpo'+ps+'*');
			itags = op2.info.itags;
			itags = pitags.subst(itags,'p',i1);
			itags = pitags.subst(itags,'v',i2);
			itags = pitags.subst(itags,'p*',i3);
			itags = pitags.subst(itags,'v*',i4);
			op2.info.itags = itags;
			op_out = qadd(op1,op2,fac);
		end

		% determine next virtual state based on previous states, 
		% position within lattice, presence of nnn and boundary conditions
		function [result] = next_state( first_states, x, y, fnnn, fPBC, deg )
			height = length(first_states(1,:));
			mpo_pos = (x-1)*height+y;

			if fnnn & fPBC
				if mpo_pos<=height+min(2,height-1)
					result = mpo_pos;
				else
					if y==height
						result = first_states(x-1,1);
					else
						if y<3
							result = first_states(x-2,height-y+1);
						else
							result = first_states(x-1,y-1);
						end
					end
				end
			else
				mpo_pos = (x-1)*height+y;
				result = mod(mpo_pos-1,deg)+1;
			end

		end

		% expand parity operator with degeneracy
		function [result] = exp_par( op_in, state_slots )
			result = QSpace;
			deg = length(state_slots);
			for i=(1:deg)
				if state_slots(i)==1
					temp = ham.exp_leg(op_in,'v',deg,i);
					temp = ham.exp_leg(temp,'v*',deg,i);
					result = qadd(result,temp,1);
				end
			end
		end

		% for given generator, make left generator, right generator,
		% left annihilator, right annihilator
		function [cd_r,cd_l,c_r,c_l] = make_quadruple( cd_in )
			cd_r = cd_in; % "r" means virtual index is on the right
			cd_r.info.itags = {'p','p*','v*'}; % p = physical, v = virtual
			c_l = conj(cd_r);
			cd_l = pitags.flip(cd_r,'v*');
			c_r = pitags.flip(c_l,'v');
		end

		% degeneracy of intermediate state
		function [deg,fnnn] = get_deg( height, t_, fPBC )
			deg = height;
			fnnn = false;
			if abs(t_)>1e-10
				fnnn = true;
			end
			if fnnn & fPBC
				deg = deg+2;
			end
			if fnnn & ~fPBC
				deg = deg+1;
			end
		end

		% get matrix product operator for Hubbard Hamiltonian
		%  t  = nn-hopping amplitude
		%  t_ = nnn-hopping amplitude
		%  U = onsite repulsion
		%  sign convention: H = -t <nn-hopping> - t_<nnn-hopping> + U<onsite-repulsion>
		%  sym = symmetry sector, either U(1)=U(1)_s x U(1)_c or SU(2)=SU(2)_s x U(1)_c
		%  width = width of cylinder
		%  height = height of cylinder
		%  fPBC = flag for periodic boundary conditions along y
		function [mpo] = get_mpo( t, t_, U, sym, width, height, fPBC )
			size = width*height;

			if strcmp(sym,'U1');
				[F,Z,S,I] = getLocalSpace('FermionS' ,'Acharge,Aspin');
			else
				[F,Z,S,I] = getLocalSpace('FermionS' ,'Acharge,SU2spin');
			end

			% fermion parity operator
			P = Z;
			P.info.itags = {'p','p*'};

			no = length(F);
			cd_r = {};
			cd_l = {};
			c_l = {};
			c_r = {};

			% hopping operators
			for i=(1:no)
				[cd_r{i},cd_l{i},c_r{i},c_l{i}] = ham.make_quadruple(F(i));
			end

			% incorporate fermion parity operator locally for operators on the left
			for i=(1:no)
				cd_P{i} = contract(P,2,cd_r{i},1);
				c_P{i} = contract(P,2,c_r{i},pitags.get_index(c_r{i}.info.itags,'p'));
			end

			% turn degree-3 into degree-4 tensors for mpo-structure
			for i=(1:no)
				cd_P{i} = ham.add_vac_leg(cd_P{i},'v');
				c_P{i} = ham.add_vac_leg(c_P{i},'v');
				cd{i} = ham.add_vac_leg(cd_l{i},'v*');
				c{i} = ham.add_vac_leg(c_l{i},'v*');
			end

			% add two-fold degeneracy for initial and final vacuum state
			for i=(1:no)
				cd_P{i} = ham.exp_leg(cd_P{i},'v',2,1);
				c_P{i} = ham.exp_leg(c_P{i},'v',2,1);
				cd{i} = ham.exp_leg(cd{i},'v*',2,2);
				c{i} = ham.exp_leg(c{i},'v*',2,2);
			end

			% make identity with two-fold degeneracy
			imat = I.E;
			imat.info.itags = {'p','p*'};
			iden1 = ham.add_vac_leg(imat,'v');
			iden1 = ham.add_vac_leg(iden1,'v*');
			iden2 = iden1;
			iden1 = ham.exp_leg(iden1,'v',2,1);
			iden1 = ham.exp_leg(iden1,'v*',2,1);
			iden2 = ham.exp_leg(iden2,'v',2,2);
			iden2 = ham.exp_leg(iden2,'v*',2,2);
			iden = iden1 + iden2;

			% make parity operator
			pop_ = P;
			pop_.info.itags = {'p','p*'};
			pop = QSpace;
			for i=(1:no)
				pop2 = ham.add_channel( pop_, cd_P{i} );
				pop = qadd(pop,pop2,1);
				pop2 = ham.add_channel( pop_, c_P{i} );
				pop = qadd(pop,pop2,1);
			end

			% make operator for onsite-repulsion
			imat = I.E;
			imat.info.itags = {'p','p*'};
			onsite = ham.add_vac_leg(imat,'v');
			onsite = ham.add_vac_leg(onsite,'v*');
			p_index = pitags.get_index(onsite.info.itags,'p');
			for i=(1:length(onsite.data))
				if ~prod(onsite.Q{p_index}(i,:)==[1 0])
					onsite.data{i} = 0;
				end
			end
			onsite.info.itags = pitags.subst(onsite.info.itags,'p','temp2');
			onsite = pitags.flip(onsite,'temp2');
			onsite = pitags.flip(onsite,'temp2*');
			onsite.info.itags = pitags.subst(onsite.info.itags,'temp2','p');
			onsite = ham.exp_leg(onsite,'v',2,1); % initial state goes in...
			onsite = ham.exp_leg(onsite,'v*',2,2); % ...final state goes out

			mpo = cell(1,size);
			for i=(1:size)
				mpo{i} = QSpace;
			end

			% initialize mpo with identities
			mpo{1} = ham.opadd(mpo{1},iden1,1,1);
			for i=(2:size-1)
				mpo{i} = ham.opadd(mpo{i},iden,1,i);
			end
			mpo{size} = ham.opadd(mpo{size},iden2,1,size);

			% insert onsite repulsion in mpo
			for i=(1:size)
				mpo{i} = ham.opadd(mpo{i},onsite,U,i);
			end

			% degeneracy of intermediate state
			deg = height;
			fnnn = false;
			if abs(t_)>1e-10
				fnnn = true;
			end
			if fnnn & fPBC
				deg = deg+2;
			end
			if fnnn & ~fPBC
				deg = deg+1;
			end

			[deg,fnnn] = ham.get_deg( height, t_, fPBC );

			% insert first term of all two-point correlations and store states
			first_states = zeros(width,height);
			for x=(1:width)
				for y=(1:height)
					mpo_pos = (x-1)*height+y;
					if mpo_pos<size
						pos = ham.next_state( first_states, x, y, fnnn, fPBC, deg );
						first_states(x,y) = pos;
						for j=(1:no)
							cd_P_mod = ham.exp_leg(cd_P{j},'v*',deg,pos);
							c_P_mod = ham.exp_leg(c_P{j},'v*',deg,pos);
							mpo{mpo_pos} = ham.opadd(mpo{mpo_pos},cd_P_mod,1,mpo_pos);
							mpo{mpo_pos} = ham.opadd(mpo{mpo_pos},c_P_mod,1,mpo_pos);
						end
					end
				end
			end

			% insert parity operators connecting hopping partners that are not
			% adjacent, but separated by at least one site along the MPO.
			if width>1 & height>1
				state_slots = zeros(1,deg);
				state = -1;
				state_prev = -1;
				for x=(1:width)
					for y=(1:height)
						mpo_pos = (x-1)*height+y;
						if mpo_pos<size
							state = first_states(x,y);
							state_slots(state) = 0; % switch off current state
							if mpo_pos>1
								state_slots(state_prev) = 1; % switch on previous state
								par = ham.exp_par( pop, state_slots );
								mpo{mpo_pos} = ham.opadd(mpo{mpo_pos},par,1,mpo_pos);
							end
						end
						state_prev = state;
					end
				end
			end

			% insert vertical nn-counterparts
			for x=(1:width)
				for y=(2:height)
					mpo_pos = (x-1)*height+y;
					pos = first_states(x,y-1);
					for i=(1:no)
						cd_mod = ham.exp_leg(cd{i},'v',deg,pos);
						c_mod = ham.exp_leg(c{i},'v',deg,pos);
						mpo{mpo_pos} = ham.opadd(mpo{mpo_pos},cd_mod,t,mpo_pos);
						mpo{mpo_pos} = ham.opadd(mpo{mpo_pos},c_mod,-t,mpo_pos);
					end
				end
				if fPBC
					mpo_pos = (x-1)*height+height;
					pos = first_states(x,1);
					for i=(1:no)
						cd_mod = ham.exp_leg(cd{i},'v',deg,pos);
						c_mod = ham.exp_leg(c{i},'v',deg,pos);
						mpo{mpo_pos} = ham.opadd(mpo{mpo_pos},cd_mod,t,mpo_pos);
						mpo{mpo_pos} = ham.opadd(mpo{mpo_pos},c_mod,-t,mpo_pos);
					end
				end
			end

			% insert horizontal nn-counterparts
			for x=(2:width)
				for y=(1:height)
					mpo_pos = (x-1)*height+y;
					pos = first_states(x-1,y);
					for i=(1:no)
						cd_mod = ham.exp_leg(cd{i},'v',deg,pos);
						c_mod = ham.exp_leg(c{i},'v',deg,pos);
						mpo{mpo_pos} = ham.opadd(mpo{mpo_pos},cd_mod,t,mpo_pos);
						mpo{mpo_pos} = ham.opadd(mpo{mpo_pos},c_mod,-t,mpo_pos);
					end
				end
			end

			if fnnn
				% insert upper-right nnn-counterparts
				for x=(2:width)
					for y=(1:height)
						mpo_pos = (x-1)*height+y;
						y_prev = y-1;
						if y_prev==0
							y_prev = height;
						end
						pos = first_states(x-1,y_prev);
						if y>1 | fPBC
							for i=(1:no)
								cd_mod = ham.exp_leg(cd{i},'v',deg,pos);
								c_mod = ham.exp_leg(c{i},'v',deg,pos);
								mpo{mpo_pos} = ham.opadd(mpo{mpo_pos},cd_mod,t_,mpo_pos);
								mpo{mpo_pos} = ham.opadd(mpo{mpo_pos},c_mod,-t_,mpo_pos);
							end
						end
					end
				end

				% insert lower-right nnn-counterparts
				for x=(2:width)
					for y=(1:height)
						mpo_pos = (x-1)*height+y;
						y_prev = y+1;
						if y_prev==height+1
							y_prev = 1;
						end
						pos = first_states(x-1,y_prev);
						if y<height | fPBC
							for i=(1:no)
								cd_mod = ham.exp_leg(cd{i},'v',deg,pos);
								c_mod = ham.exp_leg(c{i},'v',deg,pos);
								mpo{mpo_pos} = ham.opadd(mpo{mpo_pos},cd_mod,t_,mpo_pos);
								mpo{mpo_pos} = ham.opadd(mpo{mpo_pos},c_mod,-t_,mpo_pos);
							end
						end
					end
				end
			end

			% remove dangling legs at borders
			mpo{1} = ham.remove_vac_leg_border(mpo{1},'mpo0');
			ps = string(size);
			mpoindex = sprintf('%s','mpo'+ps+'*');
			mpo{size} = ham.remove_vac_leg_border(mpo{size},mpoindex);
		end

		% get virtual bond dimension of MPO for estimation of intermediate
		% bond dimensions in CBE-selections
		function [w] = get_num_mpo_states( sym, height, fPBC, t_ )
			% initial and final vacuum state
			w = 2;

			% non-trivial states for hopping
			deg = ham.get_deg( height, t_, fPBC );
			if strcmp(sym,'U1');
				w = w + 4*deg;
			else % sym=='SU2'
				w = w + 2*deg;
			end
		end

		% get product state for initialization
		%  alternating spin-up and spin-down for U(1)
		%  alternating empty and double-occ for SU(2)
		function [prod_state] = get_prod_state( N, sym )

			if strcmp(sym,'U1')
				[F,Z,S,I] = getLocalSpace('FermionS' ,'Acharge,Aspin');
				% isolate spin-up and spin-down states
				op1 = F(1);
				op2 = F(2);
				op1.data{1} = 0;
				op2.data{1} = 0;
			else
				[F,Z,S,I] = getLocalSpace('FermionS' ,'Acharge,SU2spin','NC',1);
				% isolate empty and double-occ states
				op1 = F;
				op1.data{2} = 0;
				op2 = F;
				I0 = getIdentity(op2,3,'-0');
				op2 = contract(op2,3,I0,1);
				op2.data{1} = 0;
				op2 = permute(op2,[2 1 3]);
				op2 = conj(op2);
			end

			op1.info.itags = {'p1','p2*','v*'};
			op2.info.itags = {'p1','p2*','v*'};

			% flip to get rid of zero elements
			op1 = pitags.flip(op1,'p2*');
			op2 = pitags.flip(op2,'p2*');

			% first A-tensor on the left
			prod_state = {};
			prod_state{1} = getIdentity(op1,1,'mps1');
			prod_state{1}.info.itags{1} = 'p1';

			% remaining A-tensors
			for i=(2:N)
				prev_itag = sprintf('%s','mps'+string(i-1)+'*');
				middle_itag = sprintf('%s','p'+string(i));
				next_itag = sprintf('%s','mps'+string(i)+'*');
				prev_index = pitags.get_index(prod_state{i-1}.info.itags,prev_itag);
				if mod(i,2)==0
					prod_state{i} = getIdentity(prod_state{i-1},prev_index,op2,1,next_itag);
				else
					prod_state{i} = getIdentity(prod_state{i-1},prev_index,op1,1,next_itag);
				end
				prod_state{i}.info.itags{2} = middle_itag;
			end
		end

	end
end
