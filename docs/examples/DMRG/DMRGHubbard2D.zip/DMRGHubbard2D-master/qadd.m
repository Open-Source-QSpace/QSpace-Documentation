function [result] = qadd( ten1, ten2, fac )
	if length(ten1.info)~=0
		if ~pitags.equal(ten1.info.itags,ten2.info.itags)
			ten2 = permute(ten2,pitags.get_perm(ten1.info.itags,ten2.info.itags));
		end
	end
	if length(ten1.data)==0
		result = ten2*fac;
	else
		result = ten1+(ten2*fac);
		if length(result.data)==0
			result.info = ten1.info;
		end
	end
end
