classdef TimeTracker < handle

	properties
		initial_time_map
		time_map
		initial_time
	end

	methods

		function [obj] = TimeTracker()
			obj.initial_time_map = containers.Map;
			obj.time_map = containers.Map;
			obj.initial_time = tic;
		end

		function [] = init( obj, str )
			obj.initial_time_map(str) = tic;
		end

		function [] = fin( obj, str )
			diff_time = toc(obj.initial_time_map(str));
			if ~obj.time_map.isKey(str)
				obj.time_map(str) = 0;
			end
			obj.time_map(str) = obj.time_map(str) + diff_time;
			obj.initial_time_map(str) = 0;
		end

		function [] = add( obj, other )
			other_keys_ = keys(other.time_map);
			other_values_ = values(other.time_map);
			for i=(1:length(other_keys_))
				if ~obj.time_map.isKey(other_keys_{i})
					obj.time_map(other_keys_{i}) = 0;
				end
				obj.time_map(other_keys_{i}) = obj.time_map(other_keys_{i}) + other_values_{i};
			end
		end

		function [] = print( obj )
			tot_time = toc(obj.initial_time);
			fprintf("time info\n");
			fprintf("  ratios:\n");
			keys_ = keys(obj.time_map);
			values_ = values(obj.time_map);
			for i=(1:length(keys_))
				fprintf("   %s: %.5f\n",string(keys_{i}),values_{i}/tot_time);
			end
			fprintf(" total time (sec): %.16f\n\n",tot_time);
		end

	end

end
