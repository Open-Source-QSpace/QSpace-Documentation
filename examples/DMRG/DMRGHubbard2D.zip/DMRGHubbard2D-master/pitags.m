classdef pitags % process itags
	methods(Static) 

		% flip directions of "ten_in" that match itags
		function [ten_out,I0_list] = flip_itags( ten_in, itags ) %, finv )
			I0_list = {};
			ten_out = ten_in;
			for j=(1:length(itags))
				for i=(1:length(ten_out.info.itags))
					if strcmp(ten_out.info.itags{i},itags{j})
						[ten_out,I0] = pitags.flip(ten_out,ten_out.info.itags{i}); %,finv);
						I0_list{end+1} = I0;
					end
				end
			end
		end

		function [ten_out] = flip_itags_back( ten_in, I0_list )
			ten_out = ten_in;
			for i=(1:length(I0_list))
				for j=(1:length(ten_in.info.itags))
					if strcmp(I0_list{i}.info.itags{1},ten_in.info.itags{j})
						ten_out = pitags.flip_back(ten_out,I0_list{i});
					end
				end
			end
		end

		% Flip leg of QSpace tensor "ten" labeled as "itag"
		function [ten_out,I0] = flip( ten_in, itag ) %, finv )
			index = pitags.get_index( ten_in.info.itags, itag );
			I0 = getIdentity(ten_in,index,'-0');

			I0.info.itags = {I0.info.itags{1},'temp'};
			if pitags.get_index(ten_in.info.itags,I0.info.itags{1})~=-1
				I0 = conj(I0);
			end
			ten_out = contract(ten_in,I0);
			temp = I0.info.itags{2};
			ten_out.info.itags = pitags.subst(ten_out.info.itags,temp,pitags.toggle(itag));
		end

		function [ten_out] = flip_back( ten_in, I0 )
			I0_ = conj(I0);
			itag = I0_.info.itags{1};
			temp = I0_.info.itags{2};
			I0_.info.itags = {temp,itag};
			ten_out = contract(ten_in,I0_);
			ten_out.info.itags = pitags.subst(ten_out.info.itags,temp,itag);
		end

		% get array of itags whose direction is outgoing
		function [itags_out] = get_out_tags( itags )
			itags_out = {};
			for i=(1:length(itags))
				if pitags.is_out(itags{i})
					itags_out{length(itags_out)+1} = itags{i};
				end
			end
		end 

		% check if itag is ingoing or outgoing
		function [fout] = is_out( itag )
			if length(strfind(itag,'*'))==1
				fout = true;
			else
				fout = false;
			end
		end

		function [sign_] = get_sign( itag )
			if length(strfind(itag,'*'))==1
				sign_ = -1;
			else
				sign_ = 1;
			end
		end

		% substitute "itag1" in "itags_in" by "itag2"
		function [itags_out] = subst( itags_in, itag1, itag2 )
			itags_out = itags_in;
			for i=(1:length(itags_in))
				if strcmp(itags_in{i},itag1)
					itags_out{i} = itag2;
				end
			end
		end

		% return index of "itag" within "itags"
		function [index] = get_index( itags, itag )
			index = -1;
			for i=(1:length(itags))
				if strcmp(itags{i},itag)
					index = i;
				end
			end
		end

		% get ingoing physical itag
		function [itag] = get_phys_in( itags )
			itag = '';
			for i=(1:length(itags))
				if length(strfind(itags{i},'p'))==1 & ~(length(strfind(itags{i},'mpo'))==1) & ~pitags.is_out(itags{i})
					itag = itags{i};
				end
			end
		end

		% get outgoing physical itag
		function [itag] = get_phys_out( itags )
			itag = '';
			for i=(1:length(itags))
				if length(strfind(itags{i},'p'))==1 & ~(length(strfind(itags{i},'mpo'))==1) & pitags.is_out(itags{i})
					itag = itags{i};
				end
			end
		end

		function [index_vec] = get_index_vec( itags, sub_itags )
			index_vec = [];
			for i=(1:length(sub_itags))
				index_vec(i) = pitags.get_index(itags,sub_itags{i});
			end
		end

		function [sub_pos_vec] = get_sub_pos_vec( pos_vec, sub_index_vec )
			sub_pos_vec = [];
			for i=(1:length(sub_index_vec))
				sub_pos_vec(i) = pos_vec(sub_index_vec(i));
			end
		end

		% get permutation that adapts order of "itags2" to order of "itags1",
		% i.e. apply "permute(ten2,perm)" afterwards, where ten2.info.itags==itags2
		function [perm] = get_perm( itags1, itags2 )
			len = length(itags1);
			perm = zeros(1,len);
			for i=(1:len)
				perm(i) = pitags.get_index(itags2,itags1{i});
			end
		end

		% toggle between inward and outward
		function [itag_out] = toggle( itag_in )
			if length(strfind(itag_in,'*'))==0
				itag_out = [itag_in '*'];
			else
				itag_out = strrep(itag_in,'*','');
			end
		end

		function [itags_out] = toggle_set( itags_in )
			itags_out = {};
			for i=(1:length(itags_in))
				itags_out{end+1} = pitags.toggle(itags_in{i});
			end
		end

		% make directions of all legs inward
		function [itags_out] = reset( itags_in )
			itags_out = {};
			for i=(1:length(itags_in))
				itags_out{i} = strrep(itags_in{i},'*','');
			end
		end

		% return itag with index out
		function [itag_out] = set_out( itag_in )
			itag_out = itag_in;
			if pitags.is_out(itag_in)
				itag_out = sprintf('%s',string(itag_in)+'*');
			end
		end

		% return all itags that appear in "itags_in" but not in "sub_itags"
		function [itags_out] = get_comp_itags( itags_in, sub_itags )
			itags_out = {};
			for i=(1:length(itags_in))
				if pitags.get_index(sub_itags,itags_in{i})==-1
					itags_out{length(itags_out)+1} = itags_in{i};
				end
			end
		end

		% return all itags that appear both in "itags_in" and in "sub_itags"
		function [itags_out] = get_com_itags( itags_in, sub_itags )
			itags_out = {};
			for i=(1:length(itags_in))
				if pitags.get_index(sub_itags,itags_in{i})~=-1
					itags_out{length(itags_out)+1} = itags_in{i};
				end
			end
		end

		% return all conjugated itags that appear in "itags_in" and in "sub_itags"
		function [diff_itags,com_itags] = split_conj_itags( itags_1, itags_2 )
			com_itags = {};
			diff_itags = {};
			for i=(1:length(itags_1))
				itag = pitags.toggle(itags_1{i});
				if pitags.get_index(itags_2,itag)~=-1
					com_itags{end+1} = itags_1{i};
				else
					diff_itags{end+1} = itags_1{i};
				end
			end
		end

		% physical conjugation, i.e. turn "c..." into "..." and vice versa
		function [itags_out] = conj_phys( itags_in, N )
			itags_out = itags_in;
			for i=(1:length(itags_out))
				itag = itags_out{i};
				condition_1 = (length(strfind(itag,'mps'))==1 && length(strfind(itag,string(N)))==0);
				condition_2 = (length(strfind(itag,'mps'))==0 && length(strfind(itag,'mpo'))==0 && length(strfind(itag,'p'))==1 );
				condition_3 = length(strfind(itag,'aaa'))==1; % for internal index of MPS-tensor
				if condition_1 || condition_2 || condition_3
					if itags_out{i}(1)=='c'
						itag = strrep(itag,'c','');
					else
						itag = sprintf('%s','c'+string(itag));
					end
					itags_out{i} = itag;
				end
			end
		end

		function [itags_out] = conj_phys2( itags_in, other_itags, N )
			itags_out = itags_in;
			for i=(1:length(itags_out))
				itag = itags_out{i};
				for j=(1:length(other_itags))
					if strcmp(itag,other_itags{j}) && length(strfind(itag,'mps'+string(N)))==0
						itag = sprintf('%s','c'+string(itag));
						itags_out{i} = itag;
					end
				end
			end
		end

		function [fflip] = get_fflip( itag1, itag2 )
			flag1 = true;
			if length(strfind(itag1,'*'))~=0
				flag1 = false;
			end
			flag2 = true;
			if length(strfind(itag2,'*'))~=0
				flag2 = false;
			end
			fflip = false;
			if xor(flag1,flag2)
				fflip = true;
			end
		end

		function [itag] = get_mps_itag( itags )
			itag = 'dummy';
			for i=(1:length(itags))
				if length(strfind(itags{i},'mps'))~=0
					itag = itags{i};
				end
			end
		end

		function [itag] = get_phys_itag( itags )
			for i=(1:length(itags))
				if length(strfind(itags{i},'mps'))==0
					itag = itags{i};
				end
			end
		end

		% sub itags for svd
		function [right_itags] = get_right_itags( i )
			ptag = sprintf('%s','p'+string(i));
			v2tag = sprintf('%s','mps'+string(i)+'*');
			right_itags = {ptag,v2tag};
		end

		% sub itags for svd
		function [left_itags] = get_left_itags( i )
			ptag = sprintf('%s','p'+string(i));
			v2tag = sprintf('%s','mps'+string(i-1));
			if i>1
				left_itags = {ptag,v2tag};
			else
				left_itags = {ptag};
			end
		end

		% itags left of site i
		function [left_itag] = get_left_itag( i )
			left_itag = sprintf('%s','mps'+string(i-1));
		end

		% itags left of site i
		function [left_itag] = get_left_itag2( i )
			left_itag = sprintf('%s','mps'+string(i-1)+'*');
		end

		% move itag in in_tags to front
		function [out_itags] = move_front( in_itags, itag )
			temp_itags = {};
			for i=(1:length(in_itags))
				if length(strfind(in_itags{i},itag))==0
					temp_itags{end+1} = in_itags{i};
				end
			end
			out_itags = {itag};
			for i=(1:length(temp_itags))
				out_itags{end+1} = temp_itags{i};
			end
		end

		function [result] = equal( itags1, itags2 )
			result = true;
			if length(itags1)~=length(itags2)
				result = false;
			else
				for i=(1:length(itags1))
					if ~strcmp(itags1{i},itags2{i})
						result = false;
					end
				end
			end
		end

		% print
		function [] = print( ten )
			ten.info
			for i=(1:length(ten.data))
				ten.data{i}
			end
		end

	end % methods
end % qsvd
