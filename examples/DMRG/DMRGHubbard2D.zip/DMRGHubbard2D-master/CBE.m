% controlled bond expansion
classdef CBE < handle

	properties
		left_env
		right_env
		mps1
		mps2
		mps2_
		mpo1
		mpo2
		iden
		length

		D
		D_prime
		D_hat
		D_tilde

		timetracker
	end

	methods

		function [block] = get_iden_block( obj, mps, mpo, env )
			block = mps;
			if length(env.data)>0
				block = contract(block,env);
			end
			block = contract(block,mpo);

			if length(block.data)==0
				block.info = mpo.info;
			end
		end

		function [block] = get_orth_block( obj, mps, mpo, mps2, env, middle_tag )
			block = QSpace;
			if length(mps.data)>0

				block_iden = obj.get_iden_block(mps,mpo,env);

				middle_index = pitags.get_index(mps2.info.itags,middle_tag);
				mps2_conj = conj(mps2);
				mps2_conj.info.itags = pitags.conj_phys(mps2_conj.info.itags,obj.length);
				middle_tag_conj = mps2_conj.info.itags{middle_index};
				block_tan = contract(block_iden,mps2_conj);
				mps2.info.itags = pitags.subst(mps2.info.itags,middle_tag,pitags.toggle(middle_tag_conj));
				block_tan = contract(block_tan,mps2);

				conj_mps_tags = pitags.conj_phys(mps.info.itags,obj.length);
				for i=(1:length(conj_mps_tags))
					block_iden.info.itags = pitags.subst(block_iden.info.itags,conj_mps_tags{i},mps.info.itags{i});
				end

				block = qadd(block_iden,block_tan,-1);

			end

			if length(block.data)==0
				block.info = mpo.info;
			end
		end

		function [itag] = get_middle_tag_1( obj )
			set1 = obj.mps1.info.itags;
			set2 = pitags.toggle_set(obj.mps2.info.itags);
			itags = pitags.get_com_itags(set1,set2);
			itag = itags{1};
		end

		function [itag] = get_middle_tag_2( obj )
			set1 = obj.mps2.info.itags;
			set2 = pitags.toggle_set(obj.mps1.info.itags);
			itags = pitags.get_com_itags(set1,set2);
			itag = itags{1};
		end

		% square tensor with respect to itag
		function [result,square_tag] = square( obj, ten, itag )
			ten2 = ten;
			square_tag = 'sqrtag';
			if pitags.is_out(itag)
				square_tag = pitags.toggle(square_tag);
			end
			ten2.info.itags = pitags.subst(ten2.info.itags,itag,square_tag);
			result = contract(ten,conj(ten2));
			square_tag = pitags.toggle(square_tag);
		end

		% (a), (b), (c) in FIG. S-2
		function [A_pr,right_block,pretag2] = preselection( obj )

			obj.timetracker.init("CBE preselection");

			middle_tag = obj.get_middle_tag_2();
			pretag1 = 'ptag1';
			pretag2 = 'ptag2';
			pretag3 = 'ptag3*';
			if ~pitags.is_out(middle_tag)
				pretag1 = pitags.toggle(pretag1);
				pretag2 = pitags.toggle(pretag2);
				pretag3 = pitags.toggle(pretag3);
			end

			% (a)
			obj.timetracker.init("CBE preselection (a)");
			right_block = obj.get_orth_block(obj.mps2,obj.mpo2,obj.mps2_,obj.right_env,middle_tag);
			right_block_sqr = obj.square(right_block,middle_tag);
			fac1 = Qfac;
			[Q,wft] = fac1.qr_trunc( right_block_sqr, {middle_tag}, pretag1, obj.D, 1e-10, true );
			obj.timetracker.fin("CBE preselection (a)");

			% (b)
			obj.timetracker.init("CBE preselection (b)");
			mps1_ = contract(obj.mps1,wft);
			middle_tag = obj.get_middle_tag_1();
			left_block = obj.get_orth_block(mps1_,obj.mpo1,obj.mps1,obj.left_env,middle_tag);
			left_block_sqr = obj.square(left_block,pretag1);
			[L,Q] = fac1.lq_trunc( left_block_sqr, {pretag1}, pretag3, obj.D_prime, 1e-10, true );
			left_block = contract(left_block,conj(Q));
			if length(left_block.data)==0
				left_block.info = Q.info;
				left_block.info.itags = {};
			end
			obj.timetracker.fin("CBE preselection (b)");

			% (c)
			obj.timetracker.init("CBE preselection (c)");
			prune_tags = pitags.get_com_itags(obj.mps1.info.itags,left_block.info.itags);
			[L,A_pr] = fac1.lq_trunc( left_block, prune_tags, pretag2, obj.D_hat, 1e-10 );
			obj.timetracker.fin("CBE preselection (c)");

			obj.timetracker.fin("CBE preselection");
		end

		% (d) in FIG. S-2
		function [A_tr] = final_selection( obj, A_pr, right_block, pretag2 )
			obj.timetracker.init("CBE final selection");

			pretag2_pos = pitags.get_index(A_pr.info.itags,pretag2);
			A_pr_ = conj(A_pr);
			A_pr_.info.itags = pitags.conj_phys(A_pr_.info.itags,obj.length);
			pretag2_ = A_pr_.info.itags{pretag2_pos};

			left_iden_block = obj.get_iden_block( obj.mps1, obj.mpo1, obj.left_env );
			left_block = contract(left_iden_block,A_pr_);

			full_block = contract(left_block,right_block);

			Q = QSpace;

			if length(full_block.data)>0
				full_block_sqr = obj.square(full_block,pretag2_);
				fac = Qfac;
				middle_tag = obj.get_middle_tag_2();
				[L,Q] = fac.lq_trunc( full_block_sqr, {pretag2_}, pitags.toggle(middle_tag), obj.D_tilde, 1e-10, true );
			end

			A_tr = QSpace;
			if length(Q.data)>0
				Q.info.itags = pitags.subst(Q.info.itags,pretag2_,pitags.toggle(pretag2));
				A_tr = contract(A_pr,Q);
			end

			obj.timetracker.fin("CBE final selection");
		end

		function [A_tr] = shrewd_selection( obj )
			[A_pr,right_orth_block,pretag2] = obj.preselection();
			A_tr = QSpace;
			if length(A_pr.data)>0
				A_tr = obj.final_selection(A_pr,right_orth_block,pretag2);
			end
		end

		% for quantum number sector q, get size according to q_in and size_in
		% TODO: if this is bottleneck, use containers.Map instead
		function [dim] = get_size( obj, q_in, size_in, q )
			dim = 0;
			for i=(1:length(q_in))
				if isequal(q_in{i},q)
					dim = size_in(i);
					break;
				end
			end
		end

		% input: QSpace tensor and itag
		% output: unique quantum number sectors and sizes along that dimension
		function [q_out,size_out] = unique_sectors( obj, ten_in, itag )
			index = pitags.get_index(ten_in.info.itags,itag);
			q_in = ten_in.Q{index};
			data_in = ten_in.data;

			q_out = {};
			size_out = [];
			for i=(1:length(q_in(:,1)))
				fnew = true;
				for j=(1:length(q_out))
					if isequal(q_in(i,:),q_out{j})
						fnew = false;
					end
				end
				if fnew
					q_out{end+1} = q_in(i,:);
					s = size(data_in{i});
					if index>length(s)
						size_out(end+1) = 1;
					else
						size_out(end+1) = s(index);
					end
				end
			end
		end

		% perform direct sum of tensor mps1 with truncated complement A_tr
		% expand slots filled with zeros in adjacent tensor mps2 accordingly
		function [new_mps1,new_mps2] = cbe_combine( obj, mps1, A_tr, mps2, itag )

			itag2 = pitags.toggle(itag);

			[qout1,size_out1] = obj.unique_sectors(mps1,itag);
			[qout2,size_out2] = obj.unique_sectors(A_tr,itag);

			new_tags_1 = pitags.move_front(mps1.info.itags,itag);
			mps1 = permute(mps1,pitags.get_perm(new_tags_1,mps1.info.itags));
			new_tags_2 = pitags.move_front(A_tr.info.itags,itag);
			A_tr = permute(A_tr,pitags.get_perm(new_tags_2,A_tr.info.itags));

			new_tags_3 = pitags.move_front(mps2.info.itags,itag2);
			mps2 = permute(mps2,pitags.get_perm(new_tags_3,mps2.info.itags));

			index1 = pitags.get_index(mps1.info.itags,itag);
			index2 = pitags.get_index(A_tr.info.itags,itag);

			index3 = pitags.get_index(mps2.info.itags,itag2);

			for i=(1:length(mps1.data))
				q = mps1.Q{index1}(i,:);
				dim = obj.get_size(qout2,size_out2,q);
				mps1.data{i}(end+1:end+dim,:) = 0;
			end

			for i=(1:length(mps2.data))
				q = mps2.Q{index3}(i,:);
				dim = obj.get_size(qout2,size_out2,q);
				mps2.data{i}(end+1:end+dim,:) = 0;
			end

			for i=(1:length(A_tr.data))
				q = A_tr.Q{index2}(i,:);
				dim = obj.get_size(qout1,size_out1,q);
				new_size = size(A_tr.data{i});
				new_size(1) = dim;
				A_tr.data{i} = cat(1,zeros(new_size),A_tr.data{i});
			end

			new_mps1 = qadd(mps1,A_tr,1);
			new_mps2 = mps2;
		end

		% return expanded mps-tensors
		function [new_mps1, new_mps2, tracker] = shrewd_cbe( ...
				obj, left_env, right_env, mps1, mps2, mpo1, mpo2, iden, ...
				length_, D, D_prime, D_hat, D_tilde, cbe_rank, max_rook_piv, ...
				num_zero )

			obj.left_env = left_env;
			obj.right_env = right_env;
			obj.mps1 = mps1;
			obj.mps2 = mps2;
			obj.mpo1 = mpo1;
			obj.mpo2 = mpo2;
			obj.iden = iden;
			obj.length = length_;
			obj.D = D;
			obj.D_prime = D_prime;
			obj.D_hat = D_hat;
			obj.D_tilde = D_tilde;
			obj.timetracker = TimeTracker;
			obj.timetracker.init("CBE");

			middle_tag = obj.get_middle_tag_2();
			qfac = Qfac;

			temp_itag = 'temp*';
			if pitags.is_out(middle_tag)
				temp_itag = pitags.toggle(temp_itag);
			end

			[obj.mps2_,sigma] = qfac.qr_trunc( mps2, {middle_tag}, temp_itag, 99999, 1e-10 );
			if pitags.get_index(obj.mps2_.info.itags,temp_itag)==-1
				temp_itag = pitags.toggle(temp_itag);
			end
			obj.mps2_.info.itags = pitags.subst(obj.mps2_.info.itags,temp_itag,middle_tag);

			% mind difference between mps2, which is assumed to be passed in mixed-canonical form,
			% and mps2_, which is isometry

			A_tr = obj.shrewd_selection();

			if length(A_tr.data)>0
				itag = obj.get_middle_tag_1();
				[new_mps1,new_mps2] = obj.cbe_combine( obj.mps1, A_tr, obj.mps2, itag );
			else
				new_mps1 = obj.mps1;
				new_mps2 = obj.mps2;
			end

			obj.timetracker.fin("CBE");
			tracker = obj.timetracker;
		end

	end

end
