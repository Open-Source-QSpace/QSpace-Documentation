% class for factorization
% TODO: use same 1j symbol (like Toni)
classdef Qfac < handle

	properties
		iso1
		iso2
		left_itag
		right_itag
		mat
		mci_list
		out_tags
		pos

		I0_list
	end

	methods

		% initialize factorization by flipping and fusing indices
		function [obj] = init( obj, ten, right_tags )
			left_tags = pitags.get_comp_itags( ten.info.itags, right_tags );
			obj.out_tags = pitags.get_out_tags(ten.info.itags); % get itags that point outwards

			% make sure all itags point inward
			[ten,obj.I0_list] = pitags.flip_itags(ten,obj.out_tags);

			left_tags = pitags.reset(left_tags);
			right_tags = pitags.reset(right_tags);

			% contraction with isometries can be expensive in QSpace
			% therefore, the block below determines the minimum amount of itags
			% that have to be fused for the subsequent SVD
			if length(left_tags)>=length(right_tags)
				obj.iso1 = 0;
				if length(right_tags)>1
					obj.iso2 = obj.get_isometry( ten, right_tags, 'r*' );
					obj.mat = contract(ten,conj(obj.iso2));
				else
					obj.iso2 = QSpace;
					right_pos = pitags.get_index(ten.info.itags,right_tags{1});
					if right_pos~=length(ten.info.itags);
						order = [1:length(ten.info.itags)];
						order(right_pos) = length(order);
						order(end) = right_pos;
						obj.mat = permute(ten,order);
					else
						obj.mat = ten;
					end
					obj.right_itag = obj.mat.info.itags{length(obj.mat.info.itags)};
					obj.mat.info.itags{length(obj.mat.info.itags)} = 'r';
				end
				obj.pos = length(obj.mat.info.itags);
			else
				obj.iso2 = 0;
				if length(left_tags)>1
					obj.iso1 = obj.get_isometry( ten, left_tags, 'r*' );
					obj.mat = contract(conj(obj.iso1),ten);
				else
					obj.iso1 = QSpace;
					left_pos = pitags.get_index(ten.info.itags,left_tags{1});
					if left_pos~=1
						order = [1:length(ten.info.itags)];
						order(left_pos) = 1;
						order(1) = left_pos;
						obj.mat = permute(ten,order);
					else
						obj.mat = ten;
					end
					obj.left_itag = obj.mat.info.itags{1};
					obj.mat.info.itags{1} = 'r';
				end
				obj.pos = [2:length(obj.mat.info.itags)];
			end
		end

		% make isometry with arbitrary number of ingoing legs
		function [iso] = get_isometry( obj, ten, sub_tags, new_tag )
			iso = getIdentity(ten,pitags.get_index(ten.info.itags,sub_tags{1}));
			iso.info.itags{2} = new_tag;
			for i=(2:length(sub_tags))
				iso_index = pitags.get_index(iso.info.itags,new_tag);
				ten_index = pitags.get_index(ten.info.itags,sub_tags{i});
				iso2 = getIdentity(iso,iso_index,ten,ten_index,'isotemp*');
				iso = contract(iso,iso2);
				iso.info.itags = pitags.subst(iso.info.itags,'isotemp*',new_tag);
			end
		end

		% recover original direction of itags
		function [left,right] = split( obj, left, right )
			if length(left.data)>0 && length(right)>0

				if obj.iso1==0
					if length(obj.iso2.data)>0
						right = contract(right,obj.iso2);
					else
						right.info.itags{end} = obj.right_itag;
					end
				else
					if length(obj.iso1.data)>0
						left = contract(left,obj.iso1);
					else
						left.info.itags{1} = obj.left_itag;
					end
				end

				for i=(1:length(obj.out_tags))
					obj.out_tags{i} = pitags.toggle(obj.out_tags{i});
				end
				left = pitags.flip_itags_back(left,obj.I0_list);
				right = pitags.flip_itags_back(right,obj.I0_list);
			end
		end

		% wrapper around QSpace implementation of SVD
		function [U,S,Vd,info_,sectors] = svd2( obj, D, fac_zero, fsqr )

			[U,S,Vd,info_] = svdQS( obj.mat, obj.pos, 'Nkeep', D, 'stol', fac_zero ); % actual SVD
			U = QSpace(U);

			S = diag(QSpace(S));
			if fsqr
				% For non-Abelian symmetries, the singular values in "S" can 
				% be negative if accessed via "S.data". QSpace then has another minus
				% sign under the hood which makes sure all singular values are actually
				% positive. This works well if "S" is afterwards processed via
				% contractions and additions.
				% However, in this code block I assume the factorization of the 
				% square of a tensor. Therefore, the singular values of the original
				% tensor are the square-roots of "S". Then, the minus signs cause
				% imaginary values and the program craps out. Hence the absolute value.
				for i=(1:length(S.data))
					S.data{i} = sqrt(abs(S.data{i}));
				end
			end

			sectors = {[],[],{}};
			if length(S.data)>0
				sectors{1} = S.Q{1};
				for i=(1:length(S.data))
					sectors{2}(i) = length(S.data{i}(:,1));
					sectors{3}{i} = diag(S.data{i});
				end
			end
			Vd = QSpace(Vd);
		end

		% truncated SVD, followed by pushing the weights to the right
		function [Q,R,info_,sectors] = qr_trunc( obj, ten, right_tags, new_tag, D, fac_zero, fsqr )
			if ~exist('fsqr','var')
				fsqr = false;
			end

			Q = QSpace;
			R = QSpace;
			info_ = [];
			sectors = [];

			if length(ten.data)>0
				if pitags.is_out(new_tag)
					right_tags = pitags.get_comp_itags(ten.info.itags,right_tags);
					new_tag = pitags.toggle(new_tag);
					[R,Q,info_,sectors] = obj.lq_trunc(ten, right_tags, new_tag, D, fac_zero, fsqr );
				else
					obj.init( ten, right_tags );
					[U,S,Vd,info_,sectors] = obj.svd2( D, fac_zero, fsqr );
					if length(S.data)>0
						[U,Vd] = obj.split( U, Vd );
						Q = U;
						S.info.itags{1} = new_tag;
						R = contract(S,Vd);

						index = pitags.get_index(Q.info.itags,'r*');
						if index==-1
							index = pitags.get_index(Q.info.itags,'r''*');
						end
						Q.info.itags{index} = pitags.toggle(new_tag);
					end
				end
			end

			if length(Q.data)==0
				Q.info = ten.info;
				Q.info.itags = {};
				R.info = ten.info;
				R.info.itags = {};
			end

		end

		% truncated SVD, followed by pushing the weights to the left
		function [L,Q,info_,sectors] = lq_trunc( obj, ten, right_tags, new_tag, D, fac_zero, fsqr )
			if ~exist('fsqr','var')
				fsqr = false;
			end

			L = QSpace;
			Q = QSpace;
			info_ = [];
			sectors = [];

			if length(ten.data)>0
				if pitags.is_out(new_tag)
					right_tags = pitags.get_comp_itags(ten.info.itags,right_tags);
					new_tag = pitags.toggle(new_tag);
					[Q,L,info_,sectors] = obj.qr_trunc(ten, right_tags, new_tag, D, fac_zero, fsqr );
				else
					obj.init( ten, right_tags );
					[U,S,Vd,info_,sectors] = obj.svd2( D, fac_zero, fsqr );
					if length(S.data)>0
						[U,Q] = obj.split( U, Vd );
						if length(obj.pos)>1
							S.info.itags{2} = pitags.toggle(new_tag);
						else
							S.info.itags{2} = new_tag;
							S = pitags.flip(S,new_tag);
							Q = pitags.flip(Q,'r*');
						end
						L = contract(U,S);
						Q.info.itags = pitags.subst(Q.info.itags,'r',new_tag);
					end
				end
			end

			if length(Q.data)==0
				L.info = ten.info;
				L.info.itags = {};
				Q.info = ten.info;
				Q.info.itags = {};
			end
		end

	end
end
